export const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884d8'];

export const CHART_MARGINS = {
  top: 20,
  right: 30,
  left: 40,
  bottom: 100
};